# Transform the SPARQL results into the desired list of dictionaries
# formatted_results = []
# for binding in results['results']['bindings']:
#     pet_data = {
#         'animalName': binding['animalName']['value'],
#         'microchipId': binding['MicrochipIdId']['value'],
#         'age': f"{binding['age']['value']} years",
#         'weight': f"{binding['weight']['value']} kg",
#         'owner': owner_name  # Add the owner dynamically
#     }
#     formatted_results.append(pet_data)

# print(formatted_results)